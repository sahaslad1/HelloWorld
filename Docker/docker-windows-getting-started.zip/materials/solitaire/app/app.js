(function () {
  "use strict";

  angular.module("solitaire", ["klondike", "ngDraggable"]);
})();
